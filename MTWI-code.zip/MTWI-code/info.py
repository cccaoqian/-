
1.连接服务器，搭建虚拟环境，如安装pytorch,opencv,matplotlib,numpy等包
2.训练：
在train.py中修改数据集路径，config中修改相关训练参数，最后在终端运行python train.py
3.测试：
predict.py文件中修改测试集路径，终端运行python predict.py